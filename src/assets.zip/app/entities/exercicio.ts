export interface Exercicio {
    id?: number,
    nome: string,
    tipo: string,
    agrupamento: string,
    nivel: string,
    descricao: string,
    imagePath: string,
    videoUrl: string
}