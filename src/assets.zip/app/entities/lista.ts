export interface Lista {
    id?: number,
    nome: string,
    data: Date,
    dia: string
}