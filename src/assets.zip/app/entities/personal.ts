export interface Personal {
    especialidade: string,
    descricao: string,
    redeSocial: string
}