export interface Produto {
    id?: number,
    nome: string,
    descricao: string,
    tipo: string
}