import { Component } from '@angular/core';

@Component({
  selector: 'app-header-personal',
  standalone: true,
  imports: [],
  templateUrl: './header-personal.component.html',
  styleUrl: './header-personal.component.css'
})
export class HeaderPersonalComponent {

}
