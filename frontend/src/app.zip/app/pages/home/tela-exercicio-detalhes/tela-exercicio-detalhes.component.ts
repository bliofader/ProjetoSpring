import { Component, OnInit } from '@angular/core';
import { FooterComponent } from "../../../components/footer/footer.component";
import { HeaderComponent } from "../../../components/header/header.component";
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tela-exercicio-detalhes',
  standalone: true,
  imports: [FooterComponent, HeaderComponent,CommonModule],
  templateUrl: './tela-exercicio-detalhes.component.html',
  styleUrl: './tela-exercicio-detalhes.component.css'
})
export class TelaExercicioDetalhesComponent implements OnInit {
  exercicio: any;
//banco local
  exercises = [
    { nome: 'Agachamento Livre', agrupamento: 'pernas', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Leg Press', agrupamento: 'quadriceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Panturrilha em Pé', agrupamento: 'panturrilha', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Supino Reto', agrupamento: 'peito', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Remada Curvada', agrupamento: 'costas', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Elevação Lateral', agrupamento: 'ombro', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Prancha Abdominal', agrupamento: 'abs', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Tríceps Corda', agrupamento: 'triceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Rosca Direta', agrupamento: 'biceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Rosca Alternada', agrupamento: 'biceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
  ];
  

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    const nome = this.route.snapshot.paramMap.get('nome');
    if (nome) {
      const nomeNormalizado = nome.replace(/-/g, ' ').toLowerCase();
      this.exercicio = this.exercises.find(
        (ex) => ex.nome.toLowerCase() === nomeNormalizado
      );
    }
  }
}
