import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from "../../../components/header/header.component";
import { CommonModule } from '@angular/common';
import { FooterComponent } from "../../../components/footer/footer.component";

@Component({
  selector: 'app-tela-exercicio',
  standalone: true,
  imports: [HeaderComponent, CommonModule, FooterComponent],
  templateUrl: './tela-exercicio.component.html',
  styleUrl: './tela-exercicio.component.css'
})
export class TelaExercicioComponent implements OnInit {
  selectedCategory: string = 'all';

  //banco temporario
   exercises = [
    { nome: 'Agachamento Livre', agrupamento: 'pernas', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Leg Press', agrupamento: 'quadriceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Panturrilha em Pé', agrupamento: 'panturrilha', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Supino Reto', agrupamento: 'peito', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Remada Curvada', agrupamento: 'costas', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Elevação Lateral', agrupamento: 'ombro', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Prancha Abdominal', agrupamento: 'abs', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Tríceps Corda', agrupamento: 'triceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Rosca Direta', agrupamento: 'biceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
    { nome: 'Rosca Alternada', agrupamento: 'biceps', imagePath: 'assets/images/pernas.png', descricao: 'Exercício básico para o desenvolvimento dos músculos das pernas e glúteos.' },
  ];

  filteredExercises = [...this.exercises];

  ngOnInit() {}

  filterExercises(category: string) {
    this.selectedCategory = category;
    if (category === 'all') {
      this.filteredExercises = this.exercises;
    } else {
      this.filteredExercises = this.exercises.filter(
        (exercicio) => exercicio.agrupamento === category
      );
    }
  }
}